import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.awt.event.ActionEvent;

public class Employee {

	private JFrame frame;
	private JTextField txtemployeeid;
	private JTable table;
	private JTextField txtninumber;
	private JTextField txtfirstname;
	private JTextField txtsurname;
	private JTextField txtgender;
	private JTextField txtdob;
	private JTextField txtage;
	private JTextField txtsalary;

	java.sql.Connection conn = null;
	PreparedStatement  pst = null;
	ResultSet rs = null;
	
	DefaultTableModel model = new DefaultTableModel();
	/**
	 * Launch the application.
	 */
	
	public void updateTable()
	{
		conn = EmployeeData.ConnectDB();
		if (conn !=null)
		{
			String sql = "Select Empid,NINumber,Firstname,Surname,Gender,DOB,Age,Salary";
		
		try
		{
			pst = (PreparedStatement) conn.prepareStatement(sql);
			rs = pst.executeQuery();
			Object [] columnData = new Object[8];
			
			while(rs.next()) {
				columnData [0] = rs.getString("Empid");
				columnData [1] = rs.getString("NINumber");
				columnData [2] = rs.getString("Firstname");
				columnData [3] = rs.getString("Surname");
				columnData [4] = rs.getString("Gender");
				columnData [5] = rs.getString("DOB");
				columnData [6] = rs.getString("Age");
				columnData [7] = rs.getString("Salary");
				
				model.addRow(columnData);
				
				}	
			}
			catch(Exception e)
		{
				JOptionPane.showConfirmDialog(null, e);
		}
		}
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Employee window = new Employee();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Employee() {
		initialize();
		conn = EmployeeData.ConnectDB();
		Object col[] = {"Empid", "NINumber","Firstname","Surname","Gender","DOB","Age","Salary"};
		model.setColumnIdentifiers(col);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1450, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Employee ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(10, 54, 124, 37);
		frame.getContentPane().add(lblNewLabel);
		
		txtemployeeid = new JTextField();
		txtemployeeid.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtemployeeid.setBounds(162, 52, 162, 39);
		frame.getContentPane().add(txtemployeeid);
		txtemployeeid.setColumns(10);
		
		JButton btnAddnew = new JButton("Add New");
		btnAddnew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String sql  = "INSERT into employee(Empid,NINumber,Firstname,Surname,Gender,DOB,Age,Salary)VALUES(?,?,?,?,?,?,?,?)";
				
				try
				{
				pst = (PreparedStatement) conn.prepareStatement(sql);
				pst.setString(1, txtemployeeid.getText());
				pst.setString(1, txtninumber.getText());
				pst.setString(1, txtfirstname.getText());
				pst.setString(1, txtsurname.getText());
				pst.setString(1, txtgender.getText());
				pst.setString(1, txtdob.getText());
				pst.setString(1, txtage.getText());
				pst.setString(1, txtsalary.getText());
				
				pst.execute();
				
				rs.close();
				pst.close();
				}
				catch(Exception ev)
				{
					JOptionPane.showConfirmDialog(null, "System Update Completed");
				}
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.addRow(new Object[] {
						
						txtemployeeid.getText(),
						txtninumber.getText(),
						txtfirstname.getText(),
						txtsurname.getText(),
						txtgender.getText(),
						txtdob.getText(),
						txtage.getText(),
						txtsalary.getText(),
				});
				if (table.getSelectedRow() == -1) {
					if(table.getRowCount() == 0) {
					JOptionPane.showConfirmDialog(null, "Membership Update Confirmed","Employee DataBase System",
							JOptionPane.OK_OPTION);
					}
				}
			}
		});
		btnAddnew.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnAddnew.setBounds(24, 522, 216, 43);
		frame.getContentPane().add(btnAddnew);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(506, 39, 764, 447);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"EmpID", "NINumber", "FirstName", "SurName", "Gender", "DOB", "Age", "Salary"
			}
		));
		table.setFont(new Font("Tahoma", Font.BOLD, 14));
		scrollPane.setViewportView(table);
		
		JLabel lblNiNumber = new JLabel("NI Number");
		lblNiNumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNiNumber.setBounds(10, 116, 124, 37);
		frame.getContentPane().add(lblNiNumber);
		
		txtninumber = new JTextField();
		txtninumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtninumber.setColumns(10);
		txtninumber.setBounds(162, 114, 162, 39);
		frame.getContentPane().add(txtninumber);
		
		JLabel lblFirstname = new JLabel("FirstName");
		lblFirstname.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblFirstname.setBounds(10, 164, 124, 37);
		frame.getContentPane().add(lblFirstname);
		
		txtfirstname = new JTextField();
		txtfirstname.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtfirstname.setColumns(10);
		txtfirstname.setBounds(162, 170, 162, 31);
		frame.getContentPane().add(txtfirstname);
		
		JLabel lblNewLabel_1_1 = new JLabel("SurName");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_1.setBounds(10, 212, 124, 37);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		txtsurname = new JTextField();
		txtsurname.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtsurname.setColumns(10);
		txtsurname.setBounds(162, 220, 162, 37);
		frame.getContentPane().add(txtsurname);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblGender.setBounds(10, 260, 124, 37);
		frame.getContentPane().add(lblGender);
		
		txtgender = new JTextField();
		txtgender.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtgender.setColumns(10);
		txtgender.setBounds(162, 268, 162, 37);
		frame.getContentPane().add(txtgender);
		
		JLabel lblNewLabel_1_2 = new JLabel("DOB");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_2.setBounds(10, 308, 124, 37);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		txtdob = new JTextField();
		txtdob.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtdob.setColumns(10);
		txtdob.setBounds(162, 316, 162, 37);
		frame.getContentPane().add(txtdob);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAge.setBounds(10, 363, 124, 37);
		frame.getContentPane().add(lblAge);
		
		txtage = new JTextField();
		txtage.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtage.setColumns(10);
		txtage.setBounds(162, 367, 162, 37);
		frame.getContentPane().add(txtage);
		
		JLabel lblNewLabel_1_3 = new JLabel("Salary");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1_3.setBounds(10, 411, 124, 36);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		txtsalary = new JTextField();
		txtsalary.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtsalary.setColumns(10);
		txtsalary.setBounds(162, 415, 162, 36);
		frame.getContentPane().add(txtsalary);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MessageFormat header = new MessageFormat("Printing in Process");
				MessageFormat footer = new MessageFormat("Page {0,number,integer}");
				try
				{
					table.print();
				}
				catch(java.awt.print.PrinterException ev) {
					System.err.format("No Printer found", ev.getMessage());
				}
			}
		});
		btnPrint.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnPrint.setBounds(366, 522, 231, 43);
		frame.getContentPane().add(btnPrint);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtemployeeid.setText(null);
				txtninumber.setText(null);
				txtfirstname.setText(null);
				txtsurname.setText(null);
				txtgender.setText(null);
				txtdob.setText(null);
				txtage.setText(null);
				txtsalary.setText(null);
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnReset.setBounds(700, 522, 222, 43);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Employee DataBase System",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				} 
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnExit.setBounds(1039, 522, 231, 43);
		frame.getContentPane().add(btnExit);
		
		JLabel lblNewLabel_1 = new JLabel("Employee DataBase Management System");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(372, -2, 502, 30);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
